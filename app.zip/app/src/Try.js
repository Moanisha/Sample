import React from 'react';
import App from './App'

class ppp extends React.Component {
  render() {
    return (
    <div>
      hi2
      <App/>
      </div>
    );
  }
}

export default ppp;
