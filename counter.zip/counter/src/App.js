import React from 'react';


const App=()=>{
<div className="container">
App Component
</div>
}

export default App;
